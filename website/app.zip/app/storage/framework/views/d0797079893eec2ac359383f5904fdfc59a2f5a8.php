<!DOCTYPE html>
<!--[if IE 8]> <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="no-js">
<!--<![endif]-->
<head>
<?php echo $__env->make('layout.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="page-header-fixed">
    <?php echo $__env->make('layout.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layout.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="page-content">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php echo $__env->make('layout.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layout.partials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>