    


    <?php $__env->startSection('content'); ?>
    
            <section id="start">
                <div class="team-bg parallax">
                    <div class="container">
                        <div class="heading-light">
                            <h2>
                                <img class="logo" src="assets/onepage2/img/logo_default.png" alt="CodeBB"/>
                            </h2>
                            <p>Porozmawiajmy o programowaniu</p>
                        </div>

                        <div class="row">
                                <div class="col-md-1"></div>
                            <div class="about col-md-10" >
                                <p class="text-justify">
                                    <em>
                                    CodeBB - inicjatywa której celem jest zrzeszanie pasjonatów programowania, testowania, technologii oraz dobrych i skutecznych praktyk wytwarzania oprogramowania. W ramach cyklicznych spotkań chcemy dzielić się wiedzą, doskonalić umiejętności, poszerzać horyzonty, wymieniać się doświadczeniami z innymi oraz oderwać się od codziennych zadań.
                                    Niezależnie od doświadczenia, roli czy wykorzystywanych na co dzień technologii i narzędzi, każdy powinien znaleźć tu coś dla siebie, czy to w formie słuchacza, aktywnego uczestnika czy prelegenta. 
                                    </em>
                                </p>
                                <p  class="text-right">
                                    <em>
                                        <strong>Serdecznie zapraszamy.</strong>
                                    </em>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section id="meetings">
                <div class="features-bg">
                    <div class="container">
                        <div class="heading">
                            <h2><strong>Najbliższe</strong> spotkanie</h2>
                            <h3 class="date">30.01.2019 17:00</h3>
                            <h4 class="place"><a class="accent-link" href="https://www.facebook.com/pg/klubokawiarnia.aquarium/about/?ref=page_internal" target="blank">Klubokawiarnia Aquarium - Galeria Bielska BWA: ul. 3 Maja 11 (na piętrze), 43-300 Bielsko-Biała</a></h4>
                        </div>
 
                        <div class="row md-margin-bottom-70">
                                <div class="col-md-12 md-margin-bottom-70 text-center">
                                            <h2>Agenda</h2><br/>
                                </div>
                            </div><!-- //end row -->
                        <div class="row margin-bottom-30">
                            <div class="col-md-1"></div>
                            <div class="col-md-3">
                                <div class="features">
                                    <img class="img-thumbnail rounded float-left" src="assets/meetings/dockerlogo.png" alt="">
                                </div>
                            </div>
                            <div class="col-md-7">
                                <div class="features">
                                    <div class="features-in description">
                                        <h3>Docker fajny jest a tytuł nie wiem jaki</h3>
                                        <h4>Adam Górny</h4>

                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row margin-bottom-70">
                                <div class="col-md-1"></div>
                            <div class="col-md-3 md-margin-bottom-70">
                                <div class="features">
                                    <img class="img-thumbnail rounded float-left" src="assets/meetings/rxlogo.png" alt="">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="features">
                                    <div class="features-in description">
                                            <h3>ReactiveX - tu będzie coś jeszcze</h3>
                                            <h4>Rafał Łopatka</h4>
    
                                            <p>
                                                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur,    
                                            </p>
    
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <div class="container subscribe md-margin-bottom-30">
                    <div class=" subscribe-wrap md-margin-bottom-70 ">
                        <div class="subscribe-body subscribe-desc md-margin-bottom-30">
                            <h1>Zapisz się na spotkanie</h1>
                        </div>
                        <div class="subscribe-body">
                            <form class="form-wrap input-field">
                                <div class="form-wrap-group">
                                    <input type="name" class="form-control" id="name" placeholder="Name">
                                </div>
                                <div class="form-wrap-group border-left-transparent">
                                    <input type="email" class="form-control" id="email" placeholder="Your Email">
                                </div>
                                <div class="form-wrap-group">
                                    <button type="submit" class="btn-danger btn-md btn-block">Zarejestruj się</button>
                                </div>
                            </form>
                    </div>
                </div>
            </div>
            </section>

        

            <!-- SUBSCRIBE END -->

        
            


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>