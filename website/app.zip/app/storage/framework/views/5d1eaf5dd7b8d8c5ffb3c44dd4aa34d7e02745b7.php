    <!-- BEGIN INTRO SECTION -->
    <section id="intro">
        <div id="carousel-example-generic" class="carousel slide">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                
                
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner text-uppercase" role="listbox">
                <!-- First slide -->
                

                <!-- Third slide -->
                <div class="item carousel-item-three active">
                    <div class="center-block">
                        <div class="center-block-wrap">
                            <div class="center-block-body">
                                <h3 class="motto margin-bottom-20 animate-delay carousel-title-v1" data-animation="animated fadeInDown">
                                    Porozmawiajmy o programowaniu
                                </h3>
                                <div class="page-scroll">
                                <a href="#meetings" class="join-btn animate-delay btn-brd-white" data-animation="animated fadeInUp">Dołącz</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- END INTRO SECTION -->