Return [
   
   'email' => 'kontakt@codebb.pl',
   'name' => 'CodeBB',
    
];